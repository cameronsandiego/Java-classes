
/**
 * Hello World
 * 
 * @author Cam Smith     
 * @version 01/25/2018
 * 
 * HW Proj. Handout 1. PO 1  problem 1
 */
public class HelloWorld
{
    public static void main(String[] args)
    {
        System.out.println("Aloha world!");
    }
}
