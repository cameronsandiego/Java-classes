/**
*A program that prints a poem by William Blake.
*
*
*
*@author Cameron Smith
*@version 01/30/2018
*HW Proj. Handout 1. PO 1  problem 4
*
*
*/
public class poem
{
	public static void main (String[] args)
	{
		System.out.print("\nMy mother groaned, my father wept, \nInto the dangerous world I leapt; \nHelpless, naked, piping loud, \nLike a fiend hid in a cloud.\n\nStruggling in my father's hands,	\nStriving against my swaddling bands,\nBound and weary, I thought best\nTo sulk upon my mother's breast.\n\n");

	}
	
}
