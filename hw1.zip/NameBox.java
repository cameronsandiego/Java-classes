
/**
 * My name in a box
 * 
 * @author Cam Smith     
 * @version 01/25/2018
 * 
 * HW Proj. Handout 1. PO 1  problem 1
 */
public class NameBox
{
    public static void main(String[] args)
    {
        System.out.println(" -------");
        System.out.println(" | Cam |");
        System.out.println(" -------");
    }
}
