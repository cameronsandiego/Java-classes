 
/**
 * A program that prints the names of my three best *friends, on three separate lines. 
 * 
 * @author Cam Smith     
 * @version 01/25/2018
 * 
 * HW Proj. Handout 1. PO 1  problem 3
 */
public class Friends
{
    public static void main(String[] args)
    {
    	
        System.out.println("Tony The Tiger");
        System.out.println("Kat");
        System.out.println("The Gibsonator");
    }
}
