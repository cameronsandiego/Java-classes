/**
*A program that prints a house.
*
*
*
*@author Cameron Smith
*@version 01/30/2018
*HW Proj. Handout 1. PO 1  problem 5
*
*
*/

public class house
{
	public static void main (String[] args)
	{
		System.out.print("       + \n      + +\n     +   +\n    +-----+ \n    | .-. |\n    | | | |\n    +-+-+-+  \n");






	}
}